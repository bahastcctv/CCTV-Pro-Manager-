# CCTV Pro Manager — Android Studio (Kotlin)

Starter Android app with a local SQLite product database.

## Included
- Android app in Kotlin
- Core UI language selector: Kurdish Sorani, Arabic, English
- IQD and USD price fields
- Search by product name, brand, or model
- Add CCTV products with specifications, buy/sell price, currency and stock
- Simple profit calculator
- Sample rows for camera, NVR, surveillance HDD, PoE switch and Cat6 cable

## Open in Android Studio
1. Open Android Studio and choose **Open**.
2. Select this folder.
3. Sync Gradle; JDK 17 is recommended.
4. Run on an Android device or emulator.

## Important limitations
This is a starter project. It does not yet include PDF quotations, stock editing/deletion, cloud backup, or live price updates. Demo rows have zero prices and example specs; verify exact model variants against manufacturer datasheets before quoting customers. Data is stored locally on the device.
