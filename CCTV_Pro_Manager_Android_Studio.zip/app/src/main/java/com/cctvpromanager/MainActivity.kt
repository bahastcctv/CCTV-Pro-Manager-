package com.cctvpromanager

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import android.database.sqlite.SQLiteOpenHelper
import android.database.sqlite.SQLiteDatabase
import android.content.ContentValues

data class Product(val id: Long, val name: String, val brand: String, val model: String,
 val category: String, val specs: String, val buy: Double, val sell: Double, val currency: String, val stock: Int)

class ProductDb(ctx: android.content.Context) : SQLiteOpenHelper(ctx, "cctv_products.db", null, 1) {
 override fun onCreate(db: SQLiteDatabase) {
  db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,brand TEXT,model TEXT,category TEXT,specs TEXT,buy REAL DEFAULT 0,sell REAL DEFAULT 0,currency TEXT DEFAULT 'IQD',stock INTEGER DEFAULT 0)")
  val demo = listOf(
   arrayOf("IP Camera 6MP Panoramic","Hikvision","DS-2CD2T66G2P-ISU/SL","IP Camera","6MP; 2.8mm; verify exact variant","USD"),
   arrayOf("IP Camera 4MP","Dahua","DH-IPC-HFW2441T-AS","IP Camera","4MP; verify exact variant","USD"),
   arrayOf("Network Video Recorder 8ch","Generic","NVR-8CH","NVR","8 channels; check PoE/decoding","USD"),
   arrayOf("Surveillance HDD 4TB","Generic","HDD-4TB-SURV","Storage","Surveillance-rated drive recommended","USD"),
   arrayOf("PoE Switch 8 Port","Generic","POE-8P","Network","Check total PoE power budget","USD"),
   arrayOf("Cat6 Network Cable (meter)","Generic","CAT6","Cable","Solid copper recommended for fixed runs","IQD"))
  demo.forEach { a -> val v=ContentValues(); v.put("name",a[0]); v.put("brand",a[1]); v.put("model",a[2]); v.put("category",a[3]); v.put("specs",a[4]); v.put("currency",a[5]); db.insert("products",null,v) }
 }
 override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
 fun all(q:String=""):List<Product> {
  val out=mutableListOf<Product>(); val c=readableDatabase.query("products",null,if(q.isBlank()) null else "name LIKE ? OR brand LIKE ? OR model LIKE ?",if(q.isBlank()) null else arrayOf("%$q%","%$q%","%$q%"),null,null,"name COLLATE NOCASE ASC")
  c.use { while(it.moveToNext()) out.add(Product(it.getLong(it.getColumnIndexOrThrow("id")),it.getString(it.getColumnIndexOrThrow("name"))?:"",it.getString(it.getColumnIndexOrThrow("brand"))?:"",it.getString(it.getColumnIndexOrThrow("model"))?:"",it.getString(it.getColumnIndexOrThrow("category"))?:"",it.getString(it.getColumnIndexOrThrow("specs"))?:"",it.getDouble(it.getColumnIndexOrThrow("buy")),it.getDouble(it.getColumnIndexOrThrow("sell")),it.getString(it.getColumnIndexOrThrow("currency"))?:"IQD",it.getInt(it.getColumnIndexOrThrow("stock")))) }
  return out
 }
 fun add(p:Product) { val v=ContentValues(); v.put("name",p.name);v.put("brand",p.brand);v.put("model",p.model);v.put("category",p.category);v.put("specs",p.specs);v.put("buy",p.buy);v.put("sell",p.sell);v.put("currency",p.currency);v.put("stock",p.stock);writableDatabase.insert("products",null,v) }
}

class MainActivity : Activity() {
 private lateinit var db:ProductDb
 private lateinit var list:LinearLayout
 private lateinit var search:EditText
 private var language="ku"
 private fun tr(ku:String,ar:String,en:String)=when(language){"ar"->ar;"en"->en;else->ku}
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);db=ProductDb(this);render()}
 private fun render(){
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,12,16,12);setBackgroundColor(0xFFF3F6FA.toInt())}
  root.addView(TextView(this).apply{text="📹 CCTV Pro Manager";textSize=24f;gravity=Gravity.CENTER;setTypeface(null,Typeface.BOLD);setTextColor(0xFF15375B.toInt());setPadding(0,8,0,12)})
  val spinner=Spinner(this);spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("کوردی سۆرانی","العربية","English"));spinner.setSelection(listOf("ku","ar","en").indexOf(language))
  spinner.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:android.widget.AdapterView<*>?){};override fun onItemSelected(p:android.widget.AdapterView<*>?,v:View?,pos:Int,id:Long){val n=listOf("ku","ar","en")[pos];if(n!=language){language=n;render()}}}
  root.addView(spinner)
  search=EditText(this).apply{hint=tr("گەڕان بە ناو، براند یان مۆدێل...","ابحث بالاسم أو العلامة أو الموديل...","Search name, brand or model...");singleLine=true}
  root.addView(search)
  val row=LinearLayout(this)
  row.addView(Button(this).apply{text=tr("＋ زیادکردنی بەرهەم","＋ إضافة منتج","＋ Add product");setOnClickListener{showAdd()}},LinearLayout.LayoutParams(0,-2,1f))
  row.addView(Button(this).apply{text=tr("هەژمارکردنی قازانج","حساب الربح","Profit calculator");setOnClickListener{showProfit()}},LinearLayout.LayoutParams(0,-2,1f))
  root.addView(row)
  root.addView(TextView(this).apply{text=tr("بەرهەم • نرخ • کۆگا • مواسەفات","المنتجات • الأسعار • المخزون • المواصفات","Products • Prices • Stock • Specs");setPadding(4,10,4,6);textSize=14f})
  val scroll=ScrollView(this);list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};scroll.addView(list);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)
  search.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){refresh(s?.toString()?:"")};override fun afterTextChanged(e:Editable?) {}})
  refresh()
 }
 private fun money(v:Double,c:String)=if(c=="IQD") "${"%.0f".format(v)} IQD" else "$"+"%.2f".format(v)
 private fun refresh(q:String=""){if(!::list.isInitialized)return;list.removeAllViews();val products=db.all(q);products.forEach{p->
  val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,10,12,10);setBackgroundColor(-1)}
  card.addView(TextView(this).apply{text="${p.name} • ${p.brand}";textSize=18f;setTypeface(null,Typeface.BOLD);setTextColor(0xFF183B5B.toInt())})
  card.addView(TextView(this).apply{text="${p.model}\n${p.category} | ${p.specs}\n${tr("کڕین","شراء","Buy")}: ${money(p.buy,p.currency)}    ${tr("فرۆشتن","بيع","Sell")}: ${money(p.sell,p.currency)}\n${tr("قازانج","الربح","Profit")}: ${money(p.sell-p.buy,p.currency)}    ${tr("کۆگا","المخزون","Stock")}: ${p.stock}";textSize=14f;setPadding(0,5,0,0)})
  list.addView(card,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=8})
 };if(products.isEmpty())list.addView(TextView(this).apply{text=tr("هیچ بەرهەمێک نەدۆزرایەوە","لم يتم العثور على منتجات","No products found");setPadding(8,20,8,20)})}
 private fun field(h:String)=EditText(this).apply{hint=h}
 private fun showAdd(){
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
  val name=field(tr("ناوی بەرهەم","اسم المنتج","Product name"));val brand=field("Brand / براند");val model=field("Model number");val category=field(tr("جۆری بەرهەم","الفئة","Category"));val specs=field(tr("مواسەفات","المواصفات","Specifications"))
  val buy=field(tr("نرخی کڕین","سعر الشراء","Buy price")).apply{inputType=8194};val sell=field(tr("نرخی فرۆشتن","سعر البيع","Sell price")).apply{inputType=8194};val stock=field(tr("ژمارەی کۆگا","كمية المخزون","Stock")).apply{inputType=2}
  val currency=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("IQD","USD"))}
  listOf(name,brand,model,category,specs,buy,sell,stock).forEach{box.addView(it)};box.addView(currency)
  val sc=ScrollView(this);sc.addView(box)
  AlertDialog.Builder(this).setTitle(tr("زیادکردنی بەرهەم","إضافة منتج","Add product")).setView(sc).setPositiveButton(tr("پاشەکەوت","حفظ","Save")){_,_->
   if(name.text.isBlank()){Toast.makeText(this,tr("ناوی بەرهەم پێویستە","اسم المنتج مطلوب","Product name required"),Toast.LENGTH_SHORT).show();return@setPositiveButton}
   db.add(Product(0,name.text.toString(),brand.text.toString(),model.text.toString(),category.text.toString(),specs.text.toString(),buy.text.toString().toDoubleOrNull()?:0.0,sell.text.toString().toDoubleOrNull()?:0.0,currency.selectedItem.toString(),stock.text.toString().toIntOrNull()?:0));refresh(search.text.toString())
  }.setNegativeButton(tr("هەڵوەشاندنەوە","إلغاء","Cancel"),null).show()
 }
 private fun showProfit(){
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
  val buy=field(tr("نرخی کڕین","سعر الشراء","Buy price")).apply{inputType=8194};val sell=field(tr("نرخی فرۆشتن","سعر البيع","Sell price")).apply{inputType=8194};val currency=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("IQD","USD"))}
  box.addView(buy);box.addView(sell);box.addView(currency)
  AlertDialog.Builder(this).setTitle(tr("هەژمارکردنی قازانج","حساب الربح","Profit calculator")).setView(box).setPositiveButton(tr("هەژمار بکە","احسب","Calculate")){_,_->val b=buy.text.toString().toDoubleOrNull()?:0.0;val s=sell.text.toString().toDoubleOrNull()?:0.0;AlertDialog.Builder(this).setMessage("${tr("قازانج","الربح","Profit")}: ${money(s-b,currency.selectedItem.toString())}\n${tr("ڕێژەی قازانج","هامش الربح","Margin")}: ${if(s>0)"%.1f".format((s-b)/s*100) else "0"}%").setPositiveButton("OK",null).show()}.setNegativeButton(tr("هەڵوەشاندنەوە","إلغاء","Cancel"),null).show()
 }
}
